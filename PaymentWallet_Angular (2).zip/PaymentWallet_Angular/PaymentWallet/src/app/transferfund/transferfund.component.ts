import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-transferfund',
  templateUrl: './transferfund.component.html',
  styleUrls: ['./transferfund.component.css']
})
export class TransferfundComponent implements OnInit {
  sourcebalance
  destinationbalance
  constructor() { }

  ngOnInit() {
  }
  transfund(transfer) {
    // for (let user of this.users) {
    //   if (user.accno == transfer.accno1) {
    //     this.sourcebalance = user.balance
    //     user.balance = this.sourcebalance - transfer.amount
    //   }
    // }
    // for (let user of this.users) {
    //   if (user.accno == transfer.accno2) {
    //     this.destinationbalance = user.balance
    //     user.balance = this.destinationbalance + transfer.amount
    //   }
    // }
    // alert("Fund transfer successfull")
  }
}
