import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-addbalance',
  templateUrl: './addbalance.component.html',
  styleUrls: ['./addbalance.component.css']
})
export class AddbalanceComponent implements OnInit {
  
  balance
  constructor() { }

  ngOnInit() {
  }
  addbalance(addbal)
  {
    // for(let user of this.users)
    // {
    //   if(user.accno==addbal.accno)
    //   {
    //     this.balance=user.balance
    //     this.balance=this.balance+addbal.balance
    //     user.balance=this.balance
    //     alert("Amount has been added")
    //   }
      
    // }
  }
  

}
