import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
@Component({
  selector: 'app-addaccount',
  templateUrl: './addaccount.component.html',
  styleUrls: ['./addaccount.component.css']
})
export class AddaccountComponent implements OnInit {
  Users : any;
  constructor(private service:ClientService) { }

  ngOnInit() {
  }
  createacc(create)
  {
    let model={
      custid:create.accno,
      name:create.name,
      age:create.age,
      balance:create.balance
      
    }
    // this.Users.push(create)
    this.service.create(model).subscribe(data=>this.Users=data);
    alert("Account has been created")
  }

}
