import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs/internal/observable';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private httpClient: HttpClient) { }
  public create(model): Observable<Account[]> {
    console.log(model.custid)
    return this.httpClient.post<Account[]>(`http://localhost:3456/create`,model);
  }
}
