import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-showbalance',
  templateUrl: './showbalance.component.html',
  styleUrls: ['./showbalance.component.css']
})
export class ShowbalanceComponent implements OnInit {
  balance
  constructor() { }

  ngOnInit() {
  }
  showbalance(showbal)
  {
    // for(let user of this.users)
    // {
    //   if(user.accno==showbal.accno)
    //   {
    //     this.balance=user.balance
    //     alert("Available balance is: "+this.balance)
    //   }
    // }

    
  }

}
