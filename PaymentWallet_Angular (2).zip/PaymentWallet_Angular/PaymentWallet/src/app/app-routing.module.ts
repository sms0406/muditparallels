import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddbalanceComponent} from './addbalance/addbalance.component'
import {ShowbalanceComponent} from './showbalance/showbalance.component'
import {TransferfundComponent} from './transferfund/transferfund.component'
import {AddaccountComponent} from './addaccount/addaccount.component'
const routes: Routes = [
  
  {
    path:"create",
    component:AddaccountComponent
  },
  {
    path:"addbal",
    component:AddbalanceComponent
  },
  {
    path:"showbal",
    component:ShowbalanceComponent
  },
  {
    path:"transfer",
    component:TransferfundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
