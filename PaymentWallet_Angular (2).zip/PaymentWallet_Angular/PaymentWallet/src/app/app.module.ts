import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { AddbalanceComponent } from './addbalance/addbalance.component';
import { TransferfundComponent } from './transferfund/transferfund.component';
import { FormsModule }   from '@angular/forms';
import { ShowbalanceComponent } from './showbalance/showbalance.component';
import { AddaccountComponent } from './addaccount/addaccount.component';
import {HttpClientModule} from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    MainpageComponent,
    AddbalanceComponent,
    TransferfundComponent,
    ShowbalanceComponent,
    AddaccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
