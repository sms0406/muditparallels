package com.cg.spring.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.entity.AccountsEntity;
import com.cg.spring.model.Accounts;
import com.cg.spring.repository.AccountsRepository;

@Service
@Transactional
public class AccountsService {

	@Autowired
	AccountsRepository repository;

	public String createAccount(Accounts accounts) {
		AccountsEntity entity = new AccountsEntity();
		entity.setCustId(accounts.getCustId());
		entity.setAccNo(accounts.getCustId());
		
		entity.setBalance(accounts.getBalance());
		entity.setAge(accounts.getAge());
		entity.setName(accounts.getName());
		repository.saveAndFlush(entity);
		return "Account with Account no:  " + entity.getAccNo() + " created successfully";

	}

	public String addBalance(int custId, int balance) {
		Optional<AccountsEntity> opt = repository.findById(custId);
		if (opt.isPresent()) {
			AccountsEntity entity = opt.get();
			int oldBal = entity.getBalance();
			int newBal = oldBal + balance;
			entity.setBalance(newBal);
		} else {
			System.out.println("Account no does not exists");
		}
		return "Balance added successfully";
	}

	public String showBalance(int custId) {
		Optional<AccountsEntity> opt = repository.findById(custId);
		if (opt.isPresent()) {
			AccountsEntity entity = opt.get();
			Accounts accounts = new Accounts();
			int balance = entity.getBalance();
			return "The balance in the account is:" + balance;
		} else {
			return "The account could not be found";
		}

	}

	public String transfer(int custId, int custId1, int balance) {
		System.out.println(custId+" "+custId1+balance);
		Optional<AccountsEntity> opt = repository.findById(custId);

		AccountsEntity entity = opt.get();
		if (entity.getBalance() >= balance) {
			opt = repository.findById(custId1);
			AccountsEntity entity1 = opt.get();
			entity.setBalance(entity.getBalance() - balance);
			entity1.setBalance(entity1.getBalance() + balance);
//			repository.saveAndFlush(entity);
//			repository.saveAndFlush(entity1);
			repository.save(entity);
			repository.save(entity1);

		}

		System.out.println("After transfer new balance is-" + entity.getBalance());
		return "TRnasfer successful";

	}

}
