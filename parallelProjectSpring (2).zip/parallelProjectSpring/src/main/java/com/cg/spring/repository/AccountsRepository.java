package com.cg.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.spring.entity.AccountsEntity;

public interface AccountsRepository extends JpaRepository<AccountsEntity, Integer> {

}
