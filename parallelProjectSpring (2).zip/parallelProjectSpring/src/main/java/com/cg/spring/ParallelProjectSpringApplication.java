package com.cg.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParallelProjectSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParallelProjectSpringApplication.class, args);
	}

}
