package com.cg.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.model.Accounts;
import com.cg.spring.service.AccountsService;

@CrossOrigin("http://localhost:4200")
@RestController
public class Controller {
	@Autowired
	AccountsService service;

	@PostMapping(value = "/create")
	public ResponseEntity<String> createAccount(@RequestBody Accounts accounts) {

		String response = service.createAccount(accounts);
		// return new ResponseEntity<String>(response, HttpStatus.OK);
		return ResponseEntity.ok(response);

	}

	@PutMapping(value = "/create/{custId}")
	public String addBalance(@PathVariable("custId") int custId, @RequestBody int balance) {
		return service.addBalance(custId, balance);
	}

	@GetMapping(value = "/create/{custId}")
	public ResponseEntity<String> getBalance(@PathVariable("custId") int custId) {
		String response = service.showBalance(custId);
		return ResponseEntity.ok(response);
	}

	@PutMapping(value = "/create/{custId}/{accNo}")
	public ResponseEntity<String> transferFund(@PathVariable("custId") int custId, @PathVariable("accNo") int custId1,
		@RequestBody int balance) {
		int sourceacc=custId;
		int destacc=custId1;
		String response = service.transfer(sourceacc, destacc, balance);
		return ResponseEntity.ok(response);
	}

}
